class Boards {



    public  int[] moveup(int[] origin) {

        int[] start = origin.clone();
        int begin = 0;
        int i = 0;
        while (start[i] != begin) {i++;}

        if (i <= 2) {return null;}
        else {
            int swap = start[i - 3];//Here I am moving the 0 up
            start[i - 3] = start[i];
            start[i] = swap;
        }
        return start;
    }



    public  int[] movedown(int[] origin) {

        int[] start = origin.clone();

        int begin = 0;
        int i = 0;

        while (start[i] != begin){i++;}

        if (i >=6) {return null;}

        else {
            int swap = start[i + 3];//Here I am moving the 0 up
            start[i + 3] = start[i];
            start[i] = swap;
        }

        return start;
    }

    public  int[] moveleft(int[] origin) {

        int[] start = origin.clone();

        int begin = 0;
        int i = 0;
        while (start[i] != begin) {i++;}

        if (i == 0 || i == 3 || i == 6) {return null;}

        else {
            int swap = start[i - 1];
            start[i - 1] = start[i];
            start[i] = swap;
        }
        return start;


    }

    public  int[] moveright(int[] origin)
    {
        int[] start = origin.clone();

        int begin = 0;
        int i = 0;

        while (start[i] != begin){i++;}

        if (i == 2 || i == 5 || i == 8) {return null;}
        else {
            int swap = start[i + 1];
            start[i + 1] = start[i];
            start[i] = swap;
        }

        return start;
    }
}
