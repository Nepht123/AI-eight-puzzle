public class Main {
    public static void main(String[] args) {
        Boards move = new Boards();

        int[] start={1,2,3,4,0,5,6,7,8};
        System.out.println("Here is the starting state");

        for(int i:start){
            System.out.print(i+" ");
        }
        System.out.println();

        System.out.println("Bellow are all the moves");


        int[] moveup=move.moveup(start);
        for(int i:moveup)
        {
            System.out.print(i+" ");
        }

        System.out.println();

        int[] movedown=move.movedown(start);
        for(int i:movedown)
        {
            System.out.print(i+" ");
        }

        System.out.println();

        int[] moveleft=move.moveleft(start);
        for(int i:moveleft)
        {
            System.out.print(i+" ");
        }

        System.out.println();


        int[] moveright=move.moveright(start);
        for(int i:moveright)
        {
            System.out.print(i+" ");
        }

        System.out.println();
    }
}


