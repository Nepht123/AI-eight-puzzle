import java.util.*;
import java.io.*;

public class EightPuzzle {
    static class State implements Comparable<State> {
        private int[] board;
        private int gValue;
        private int hValue;
        private State parent;

        public State(int[] board) {
            this.board = Arrays.copyOf(board, board.length);
            this.gValue = 0;
            this.hValue = 0;
            this.parent = null;
        }

        public int[] getBoard() {
            return board;

        }

        //public int getGValue() {return gValue;}

        //public void setGValue(int g) {this.gValue = g;}


        public int getHValue() {
            return hValue;

        }

        public void setHValue(int h) {
            this.hValue = h;

        }

        public State getParent() {

            return this.parent;
        }

        public void setParent(State p) {
            this.parent = p;

        }


        public List<State> getChildren() {
            List<State> children = new ArrayList<>();
            Boards move=new Boards();

            int[][] moves={move.moveleft(this.board),move.moveup(this.board),move.moveright(this.board),move.movedown(this.board)};

            for(int[] nextBoard:moves)
            {
                if(nextBoard!=null)
                {
                    State child=new State(nextBoard);

                    child.setParent(this);
                    child.calculateHeuristic();
                    children.add(child);

                }
            }


            return children;
        }


        public void calculateHeuristic() {
            int [] goal={1,2,3,4,5,6,7,8,0};
            int[] board=this.getBoard();
            int count=0;

            for(int i=0; i<goal.length; i++)
            {
                if(board[i] != goal[i])
                {
                    count++;
                }
            }

            this.setHValue(count);


        }

        @Override
        public int compareTo(State o) {
            return Integer.compare(this.hValue, o.hValue);
        }

        public boolean isGoal() {
            int[] goal = {1, 2, 3, 4, 5, 6, 7, 8, 0};
            return Arrays.equals(this.board, goal);
        }

        public String getKey() {
            return Arrays.toString(board);
        }

        public void printState() {
            for(int i=1;i<board.length+1;i++)
            {
                if(i%3==0)
                {
                    System.out.print(board[i-1]);
                    System.out.println();
                }
                else
                {
                    System.out.print(board[i-1]+", ");
                }

            }
        }

    }

    public static void search(State start) {
        PriorityQueue<State> frontier = new PriorityQueue<>();
        Set<String> explored = new HashSet<>();

        frontier.add(start);
        explored.add(start.getKey());

        while(!frontier.isEmpty())
        {
                State current = frontier.poll();

                if(current.isGoal())
                {
                    printSolution(current);
                    break;
                }
                else
                {
                    List<State> children = current.getChildren();
                    for(State kids:children)
                    {
                        if(!explored.contains(kids.getKey()))
                        {
                            frontier.add(kids);
                            explored.add(kids.getKey());

                        }
                    }
                }


        }


    }




    public static void printSolution(State goal)
    {
        List<State> parents = new ArrayList<>();
        State current= goal;
        parents.add(current);
        while(current.getParent()!=null)
        {
            current=current.getParent();
            parents.add(current);
        }

        List<State> path=parents.reversed();
        System.out.println("Here is our initial state:");
        for(State road:path)
        {
            road.printState();
            System.out.println();

        }
        System.out.println("Solved in " + (path.size() - 1) + " moves!");

    }




    public static int[] readFile(String filename) {
        try {
            Scanner scan = new Scanner(new File(filename));
            int[] board = new int[9];
            for (int i = 0; i < 9; i++) {
                board[i] = scan.nextInt();
            }
            scan.close();
            return board;
        } catch (Exception e) {
            System.out.println("Error reading file.");
            return null;
        }
    }

    public static void main(String[] args) {
        int[] startBoard = readFile("C:\\Users\\mwamb\\OneDrive\\Desktop\\Comp Sci HQ\\Lectures_Artificial Inteligence\\AI_redemption\\Redemption\\src\\StateA.txt");
        State start = new State(startBoard);

        search(start);
    }
}